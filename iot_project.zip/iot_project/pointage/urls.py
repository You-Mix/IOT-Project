from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("new_personnel", views.new_personnel, name="new_personnel"),
    path("login", views.connexion, name="connexion"),
    path("logout", views.deconnection, name="deconnection"),
    path("pointage/<int:personnelID>", views.pointage, name="pointage"),
    path("pointages/", views.pointages, name="pointages"),
    path("personnels/", views.personnels, name="personnels"),

]