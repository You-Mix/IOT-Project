from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import *
from datetime import date, datetime, time
from django.db.models import Q
# Create your views here.
def index(request):
    if request.user.is_authenticated:
        context = {
            "personnels" : Personnel.objects.all().order_by('-id'),
            "pointages" : Pointage.objects.filter(date__date=date.today()).order_by('-heure_depart'),
            "today" : date.today(),
        }
        return render(request, "pointage/index.html", context)
    else:
        return redirect(connexion)



def personnels(request):
    if request.user.is_authenticated:
        context = {
            "personnels" : Personnel.objects.all(),
        }
        return render(request, "pointage/personnels.html", context)
    else:
        return redirect(connexion)
    

def pointages(request):
    if request.user.is_authenticated:
        context = {
            "pointages" : Pointage.objects.all().order_by('-heure_depart'),
        }
        return render(request, "pointage/pointages.html", context)
    else:
        return redirect(connexion)




def new_personnel(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            rfid = request.POST["id_input"]
            personnel_exist = Personnel.objects.filter(rfid = rfid)
            if len(personnel_exist) == 0:
                nom = request.POST["nom_input"]
                matricule = request.POST["matricule_input"]
                fonction = request.POST["fonction_input"]
                phone = request.POST["phone_input"]
                email = request.POST["email_input"]
                sexe = request.POST["sexe_input"]

                hot_personnel = Personnel.objects.create(rfid=rfid, nom=nom, matricule=matricule, fonction=fonction, phone=phone, email=email, sexe=sexe)
                hot_personnel.save()
                return redirect(personnels)
            else:
                print("Already exist")
                return redirect(index)
    else:
        return redirect(connexion)

def connexion(request):
    if not request.user.is_authenticated:
        if request.method == "POST":
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            if user is not None and user.is_active:
                login(request, user)
                messages.success(request, "Login succesfully")
                return redirect('index')
            else:
                messages.error(request, "ERREUR !!!")
        return render(request, "pointage/login.html")
    else:
        return redirect(index)
    
@login_required
def deconnection(request):
    logout(request)
    return redirect("connexion")


def pointage(request, personnelID):
    personnel = Personnel.objects.filter(rfid=personnelID)
    print(personnel)
    if len(personnel) != 0:
        point = Pointage.objects.filter(Q(date__date=datetime.today().date()) and Q(personnel=personnel[0]))
        print(point)
        if len(point) == 0:
            hot_pointage = Pointage.objects.create(personnel = personnel[0], date=datetime.today(), heure_depart=datetime.today().time())
            hot_pointage.save()
        else:
            point[0].heure_depart = datetime.today().time()
            point[0].save()
    
    return redirect("index")