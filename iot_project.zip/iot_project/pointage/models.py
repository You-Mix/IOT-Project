from django.db import models

# Create your models here.
class Personnel(models.Model):
    rfid = models.IntegerField(unique=True)
    nom = models.CharField(max_length=200)
    SEXE_CHOICE = (
        ('F',"Feminin"),
        ('M',"Masculin")
    )
    sexe = models.CharField(max_length=10, choices=SEXE_CHOICE)
    matricule = models.CharField(max_length=10)
    fonction = models.CharField(max_length=200)
    phone = models.CharField(max_length=200, null=True)
    email = models.EmailField(max_length=200, null=True)

    def __str__(self):
        return self.nom


class Pointage(models.Model):
    personnel = models.ForeignKey(Personnel, on_delete=models.CASCADE)
    date = models.DateTimeField()
    heure_depart = models.TimeField()
